class ApplicationMailer < ActionMailer::Base
  default from: "Profitability App <noreply@profitability.com>"
  layout 'mailer'
end
