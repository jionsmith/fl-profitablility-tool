module V1
  class ProjectTimelineSerializer < ActiveModel::Serializer
    attributes :weekly_timelines
    def weekly_timelines
    end
  end
end
