module V1
  class TimelineSerializer < ActiveModel::Serializer
    attributes :id
  end
end
