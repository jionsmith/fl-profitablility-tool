module V1
  class ProjectTypeSerializer < ActiveModel::Serializer
    attributes :id, :name
  end
end
